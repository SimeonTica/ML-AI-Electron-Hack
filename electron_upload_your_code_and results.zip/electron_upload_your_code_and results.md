
# Live Leaderboard for Denoising/Image Enhacement and Object Detection

In order to check yourself live against the other you can enhance the 10 images in the evaluation directory and predict the objects for the validation set resulting in your predictions.json. 

![Eval-Dir](images/evaluation_dir.jpeg)

Upload your 10 enhanced images and your resulted json for object detection on the evaluation set on the following website: https://biosinf.pub.ro/electron

The backend code of the website will automatically test your output results (i.e. the images and json) and will place you with the according PSNR and AP on the leaderboard.

Do not worry if the AP on the leaderboard seems lower than what you get locally. The AP on the leaderboard is still scaled correctly.

![Leaderboard](images/leaderboard.jpeg)

# IMPORTANT

You can also **upload your code and weights**/checkpoints/model by clicking **Incarca Script**. Every time you upload it will overwrite the previous data. By uploading your code and model you allow us to test your model on the hidden test. If you do not upload the code and model you may be **disqualified**.

Remember to follow the guidelines. The file inference.py should exist for each task (i.e. image enhancement and object detection) and it should be very easy to run as such:

```
python inference.py --input_path input --output_path 
```

## Question

If you have any question, do not hestitate, at any moment, to address them on our Discord, or to any person that can get you, to the developers that build the leaderboard.