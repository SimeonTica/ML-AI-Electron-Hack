To run the script run the command python inference.py --input_path path/to/inpfut --output_path path/to/output.
The model should be in the same folder as the script.
The ipynb notebook is a presentation of the creational process linked to the building of the model